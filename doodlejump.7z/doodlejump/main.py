import pygame
import sys

from singleton import Singleton
from camera import Camera
from player import Player
from level import Level
import settings as config

# Define new colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

# New player size
PLAYER_WIDTH = 50
PLAYER_HEIGHT = 50

# New platform size
PLATFORM_WIDTH = 150
PLATFORM_HEIGHT = 20


class Bonus(pygame.sprite.Sprite):

    def __init__(self, parent, color=YELLOW, force=config.PLAYER_BONUS_JUMPFORCE):
        super().__init__()
        self.image = pygame.Surface((20, 20))
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.centerx = parent.rect.centerx
        self.rect.y = parent.rect.y - 30
        self.force = force

    def update(self):
        pass


class Platform(pygame.sprite.Sprite):

    def __init__(self, x, y, width, height):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        pass


class Game(Singleton):


    def __init__(self):
       
        self.__alive = True
        self.window = pygame.display.set_mode(config.DISPLAY, config.FLAGS)
        self.clock = pygame.time.Clock()
        self.camera = Camera()
        self.lvl = Level()
        self.player = Player(
            config.HALF_XWIN - PLAYER_WIDTH // 2,
            config.HALF_YWIN + config.HALF_YWIN // 2,
            PLAYER_WIDTH,
            PLAYER_HEIGHT,
            BLUE,
        )

        self.score = 0
        self.score_font = pygame.font.Font(None, 36)

    def close(self):
        self.__alive = False

    def reset(self):
        self.camera.reset()
        self.lvl.reset()
        self.player.reset()

    def _event_loop(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.close()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.close()
                if event.key == pygame.K_RETURN and self.player.dead:
                    self.reset()
            self.player.handle_event(event)

    def _update_loop(self):
        self.player.update()
        self.lvl.update()

        if not self.player.dead:
            self.camera.update(self.player.rect)
            self.score = -self.camera.state.y // 50

    def _render_loop(self):
        self.window.fill(WHITE)
        self.lvl.draw(self.window)
        self.player.draw(self.window)

        if self.player.dead:
            gameover_text = self.score_font.render("Game Over", True, BLACK)
            gameover_rect = gameover_text.get_rect(center=(config.HALF_XWIN, config.HALF_YWIN))
            self.window.blit(gameover_text, gameover_rect)

        score_text = self.score_font.render(f"{self.score} m", True, BLACK)
        self.window.blit(score_text, (10, 10))

        pygame.display.update()
        self.clock.tick(config.FPS)

    def run(self):
        while self.__alive:
            self._event_loop()
            self._update_loop()
            self._render_loop()
        pygame.quit()


if __name__ == "__main__":
    game = Game()
    game.run()
