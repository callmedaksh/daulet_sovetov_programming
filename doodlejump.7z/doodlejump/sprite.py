from pygame import Surface, Rect
from camera import Camera

class Sprite:
    def __init__(self, x: int, y: int, w: int, h: int, color: tuple, alpha: int = 255):
        self.__color = color
        self._image = Surface((w, h))
        self._image.fill(color)
        self._image.set_alpha(alpha)  # Set transparency (alpha value)
        self._image = self._image.convert_alpha()  # Use alpha transparency
        self.rect = Rect(x, y, w, h)
        self.camera_rect = self.rect.copy()

    @property
    def image(self) -> Surface:
        return self._image

    @property
    def color(self) -> tuple:
        return self.__color

    @color.setter
    def color(self, new: tuple) -> None:
        """ Called when Sprite.__setattr__('color', x). """
        assert isinstance(new, tuple) and len(new) == 3, "Value is not a color"
        self.__color = new
        self._image.fill(self.color)
        self._image.set_alpha(255)  # Reset alpha to fully opaque

    def set_transparency(self, alpha: int) -> None:

        self._image.set_alpha(alpha)

    def draw(self, surface: Surface) -> None:
  
        if Camera.instance:
            self.camera_rect = Camera.instance.apply(self)
            surface.blit(self._image, self.camera_rect)
        else:
            surface.blit(self._image, self.rect)
