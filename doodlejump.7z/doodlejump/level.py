from random import randint
import pygame
import asyncio

from singleton import Singleton
from sprite import Sprite
import settings as config


chance = lambda x: not randint(0, x)


class Bonus(Sprite):

    WIDTH = 25
    HEIGHT = 25

    def __init__(self, parent: Sprite, color=pygame.Color("green"), force=config.PLAYER_BONUS_JUMPFORCE):
        self.parent = parent
        super().__init__(*self._get_initial_pos(), Bonus.WIDTH, Bonus.HEIGHT, color)
        self.force = force

    def _get_initial_pos(self):
        x = self.parent.rect.centerx - Bonus.WIDTH // 2
        y = self.parent.rect.y - Bonus.HEIGHT
        return x, y


class Platform(Sprite):

    def __init__(self, x: int, y: int, width: int, height: int, initial_bonus=False, breakable=False):
        color = pygame.Color("orange")
        if breakable:
            color = pygame.Color("purple")
        super().__init__(x, y, width, height, color)

        self.breakable = breakable
        self.__level = Level.instance
        self.__bonus = None
        if initial_bonus:
            self.add_bonus(Bonus)

    @property
    def bonus(self):
        return self.__bonus

    def add_bonus(self, bonus_type: type) -> None:
        assert issubclass(bonus_type, Bonus), "Not a valid bonus type!"
        if not self.__bonus and not self.breakable:
            self.__bonus = bonus_type(self)

    def remove_bonus(self) -> None:
        self.__bonus = None

    def onCollide(self) -> None:
        if self.breakable:
            self.__level.remove_platform(self)

    def draw(self, surface: pygame.Surface) -> None:
        super().draw(surface)
        if self.__bonus:
            self.__bonus.draw(surface)
        if self.camera_rect.y + self.rect.height > config.YWIN:
            self.__level.remove_platform(self)


class Level(Singleton):

    def __init__(self):
        self.platform_size = (120, 20)
        self.max_platforms = config.MAX_PLATFORM_NUMBER
        self.distance_min = min(config.PLATFORM_DISTANCE_GAP)
        self.distance_max = max(config.PLATFORM_DISTANCE_GAP)

        self.bonus_platform_chance = config.BONUS_SPAWN_CHANCE
        self.breakable_platform_chance = config.BREAKABLE_PLATFORM_CHANCE

        self.__platforms = []
        self.__to_remove = []

        self.__base_platform = Platform(
            config.HALF_XWIN - self.platform_size[0] // 2,
            config.HALF_YWIN + config.YWIN / 3,
            *self.platform_size)

    @property
    def platforms(self) -> list:
        return self.__platforms

    async def _generation(self) -> None:
        nb_to_generate = self.max_platforms - len(self.__platforms)
        for _ in range(nb_to_generate):
            self.create_platform()

    def create_platform(self) -> None:
        if self.__platforms:
            offset = randint(self.distance_min, self.distance_max)
            self.__platforms.append(Platform(
                randint(0, config.XWIN - self.platform_size[0]),
                self.__platforms[-1].rect.y - offset,
                *self.platform_size,
                initial_bonus=chance(self.bonus_platform_chance),
                breakable=chance(self.breakable_platform_chance)))
        else:
            self.__platforms.append(self.__base_platform)

    def remove_platform(self, plt: Platform) -> bool:
        if plt in self.__platforms:
            self.__to_remove.append(plt)
            return True
        return False

    def reset(self) -> None:
        self.__platforms = [self.__base_platform]

    def update(self) -> None:
        for platform in self.__to_remove:
            if platform in self.__platforms:
                self.__platforms.remove(platform)
        self.__to_remove = []
        asyncio.run(self._generation())

    def draw(self, surface: pygame.Surface) -> None:
        for platform in self.__platforms:
            platform.draw(surface)
